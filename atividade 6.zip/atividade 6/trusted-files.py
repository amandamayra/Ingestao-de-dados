import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import boto3
from io import BytesIO
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql import SparkSession

# Configuração geral
bucket_name = 'grupo7-bucket-raw'
bucket_final = 'grupo7-bucket-trusted'
s3_client = boto3.client('s3')

# Funções comuns para manipulação de dados

def le_parquet_s3(bucket_name, file_path):
    """Lê um arquivo Parquet do S3 e retorna um DataFrame Pandas."""
    response = s3_client.get_object(Bucket=bucket_name, Key=file_path)
    file_content = response['Body'].read()
    df = pd.read_parquet(BytesIO(file_content), engine='pyarrow')
    return df

def faz_upload_s3(df, bucket_name, file_path):
    """Converte um DataFrame Pandas para Parquet e faz upload para o S3."""
    buffer = BytesIO()
    table = pa.Table.from_pandas(df)
    pq.write_table(table, buffer)
    buffer.seek(0)  # Voltar ao início do buffer
    s3_client.upload_fileobj(buffer, bucket_final, file_path)
    print(f'Arquivo {file_path} salvo com sucesso no bucket {bucket_final}.')

def processa_trusted_banco():
    """Processa dados para a tabela trusted_bancos."""
    df = le_parquet_s3(bucket_name, 'raw_bancos.parquet')

    # Transformações de dados
    df['segmento'] = df['segmento'].astype(str)
    df['cnpj'] = df['cnpj'].astype(str)
    df['nome'] = df['nome'].astype(str)
    df.rename(columns={'segmento': 'segment', 'nome': 'name'}, inplace=True)

    # Upload para a camada Trusted
    faz_upload_s3(df, bucket_name, 'trusted_bancos.parquet')
    save_to_aurora_mysql(df, 'trusted_bancos')

def processa_trusted_empregados():
    """Processa dados para a tabela dw_employees."""
    df = le_parquet_s3(bucket_name, 'raw_empregados.parquet')

    # Transformações de dados
    conversion_dict = {
        'employer_name': str, 'reviews_count': int, 'culture_count': int, 'salaries_count': float,
        'benefits_count': int, 'employer_website': str, 'employer_headquarters': str,
        'employer_founded': float, 'employer_industry': str, 'employer_revenue': str,
        'url': str, 'geral': float, 'cultura_e_valores': float, 'diversidade_e_inclusao': float,
        'qualidade_de_vida': float, 'alta_lideranca': float, 'remuneracao_e_beneficios': float,
        'oportunidades_de_carreira': float, 'percentual_recomendam_para_outras_pessoas': float,
        'percentual_perspectiva_positiva_da_empresa': float, 'cnpj': str, 'nome': str,
        'match_percent': str, 'segmento': str
    }

    # Convertendo tipos de dados
    for column, dtype in conversion_dict.items():
        df[column] = df[column].fillna(0).astype(dtype)

    # Renomeação das colunas
    rename_dict = {
        'geral': 'general', 'cultura_e_valores': 'culture_and_values', 
        'diversidade_e_inclusao': 'diversity_and_inclusion', 'qualidade_de_vida': 'quality_of_life',
        'alta_lideranca': 'high_leadership', 'remuneracao_e_beneficios': 'remuneration_and_benefits',
        'oportunidades_de_carreira': 'career_opportunities', 
        'percentual_recomendam_para_outras_pessoas': 'percentage_recommend_to_other_people',
        'percentual_perspectiva_positiva_da_empresa': 'percentage_positive_perspective_of_the_company',
        'nome': 'name', 'segmento': 'segment'
    }
    df.rename(columns=rename_dict, inplace=True)

    # Upload para a camada Trusted
    faz_upload_s3(df, bucket_name, 'trusted_empregados.parquet')
    save_to_aurora_mysql(df, 'trusted_empregados')

def processa_trusted_reclamacoes():
    """Processa dados para a tabela dw_complaints."""
    df = le_parquet_s3(bucket_name, 'raw_reclamacoes.parquet')

    # Substituir NA por 0 e ajustar tipos de dados
    df.fillna(0, inplace=True)
    columns_to_string = ['ano', 'trimestre', 'categoria', 'tipo', 'cnpj', 'instituicao_financeira', 
                         'indice', 'quantidade_de_reclamacoes_reguladas_procedentes',
                         'quantidade_de_reclamacoes_reguladas_outras', 
                         'quantidade_de_reclamacoes_nao_reguladas', 'quantidade_total_de_reclamacoes',
                         'quantidade_total_de_clientes_ccs_e_scr', 'quantidade_de_clientes_ccs', 
                         'quantidade_de_clientes_scr']
    
    df[columns_to_string] = df[columns_to_string].astype(str)

    # Renomeação das colunas
    rename_dict = {
        'ano': 'year', 'trimestre': 'quarter', 'categoria': 'category', 
        'tipo': 'type_category', 'instituicao_financeira': 'financial_institution', 
        'indice': 'index', 'quantidade_de_reclamacoes_reguladas_procedentes': 'quantity_of_regulated_complaints_found',
        'quantidade_de_reclamacoes_reguladas_outras': 'quantity_of_regulated_complaints_others',
        'quantidade_de_reclamacoes_nao_reguladas': 'quantity_of_non_regulated_complaints',
        'quantidade_total_de_reclamacoes': 'total_quantity_of_complaints', 
        'quantidade_total_de_clientes_ccs_e_scr': 'total_quantity_of_clients_ccs_e_scr',
        'quantidade_de_clientes_ccs': 'quantity_of_ccs_clients', 
        'quantidade_de_clientes_scr': 'quantity_of_customers_scr'
    }
    df.rename(columns=rename_dict, inplace=True)

    # Upload para a camada Trusted
    faz_upload_s3(df, bucket_name, 'trusted_reclamacoes.parquet')
    save_to_aurora_mysql(df, 'trusted_reclamacoes')

def save_to_aurora_mysql(df, table_name):
    """Salva um DataFrame no Aurora MySQL usando JDBC."""
    sc = SparkContext.getOrCreate()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session

    # Criar um DataFrame do Spark a partir do DataFrame Pandas
    spark_df = spark.createDataFrame(df)

    # Configurações do Aurora MySQL
    aurora_mysql_url = 'jdbc:mysql://db-grupo7.cluster-chmm4000kktq.us-east-1.rds.amazonaws.com:3306/db-grupo7'  # Substitua pelo endpoint do seu cluster e nome do banco de dados
    aurora_mysql_properties = {
        'user': 'admin',  # Substitua pelo nome de usuário do banco de dados
        'password': 'ung308(884QVx~aTL[Y>7f6MjG4r',  # Substitua pela senha do banco de dados
        'driver': 'com.mysql.cj.jdbc.Driver'
    }

    # Salvar o DataFrame no Aurora MySQL
    spark_df.write.jdbc(url=aurora_mysql_url, table=table_name, mode='overwrite', properties=aurora_mysql_properties)
    print(f'Dados carregados com sucesso na tabela {table_name} no Aurora MySQL.')

# Chamadas das funções de processamento
processa_trusted_banco()
processa_trusted_empregados()
processa_trusted_reclamacoes()