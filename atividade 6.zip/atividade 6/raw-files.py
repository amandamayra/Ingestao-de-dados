
import io
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import boto3
from io import BytesIO

def lambda_handler(event, context):
    try:
        # Parte 1: Processamento dos Dados de Bancos
        processar_dados_bancos()

        # Parte 2: Processamento dos Dados de Empregados
        processar_dados_empregados()

        # Parte 3: Processamento dos Dados de Reclamações
        processar_dados_reclamacoes()

        print('Processamento concluído com sucesso.')
    except Exception as e:
        print('Erro:', e)


def processar_dados_bancos():
    # Variáveis
    bucket_name = 'arquivo-inicial'
    bucket_final = 'grupo7-bucket-raw'
    raw_file_path = 'raw_bancos.parquet'
    file_path_bancos = 'Dados/Bancos/EnquadramentoInicia_v2.tsv'  # Caminho no S3

    # Inicializar o cliente S3
    s3_client = boto3.client('s3')

    # Obter o arquivo S3 para a memória
    response = s3_client.get_object(Bucket=bucket_name, Key=file_path_bancos)
    file_content = response['Body'].read()

    # Ler o arquivo TSV para um DataFrame usando pandas
    columns_name = ['segmento', 'cnpj', 'nome']
    df = pd.read_csv(BytesIO(file_content), names=columns_name, header=0, sep='\t', encoding='ISO-8859-1')

    # Convertendo DataFrame para Parquet em um buffer de memória
    buffer = BytesIO()
    table = pa.Table.from_pandas(df)
    pq.write_table(table, buffer)

    # Fazendo o upload para o S3
    buffer.seek(0)  # Voltar ao início do buffer
    s3_client.upload_fileobj(buffer, bucket_final, raw_file_path)
    print(f'Arquivo {raw_file_path} salvo com sucesso no bucket {bucket_final}.')


def processar_dados_empregados():
    # Variáveis
    bucket_name = 'arquivo-inicial'
    raw_file_path = 'raw_empregados.parquet'
    bucket_final = 'grupo7-bucket-raw'
    file_path_less = 'Dados/Empregados/glassdoor_consolidado_join_match_less_v2.csv'
    file_path_match = 'Dados/Empregados/glassdoor_consolidado_join_match_v2.csv'

    # Inicializar o cliente S3
    s3_client = boto3.client('s3')

    # Obter arquivos S3 para a memória
    response_less = s3_client.get_object(Bucket=bucket_name, Key=file_path_less)
    response_match = s3_client.get_object(Bucket=bucket_name, Key=file_path_match)

    # Ler o conteúdo dos arquivos CSV para DataFrames usando o delimitador correto
    df_less = pd.read_csv(BytesIO(response_less['Body'].read()), sep='|', engine='python')  # Usar o delimitador correto
    df_match = pd.read_csv(BytesIO(response_match['Body'].read()), sep='|', engine='python')  # Usar o delimitador correto

    # Normalizar nomes de colunas: remover espaços em branco e converter para minúsculas
    df_less.columns = df_less.columns.str.strip().str.lower()
    df_match.columns = df_match.columns.str.strip().str.lower()

    # Definir os nomes de colunas desejados após normalização
    colunas_desejadas = ['employer_name', 'reviews_count', 'culture_count', 'salaries_count', 'benefits_count',
                         'employer_website', 'employer_headquarters', 'employer_founded', 'employer_industry',
                         'employer_revenue', 'url', 'geral', 'cultura_e_valores', 'diversidade_e_inclusao',
                         'qualidade_de_vida', 'alta_lideranca', 'remuneracao_e_beneficios', 'oportunidades_de_carreira',
                         'percentual_recomendam_para_outras_pessoas', 'percentual_perspectiva_positiva_da_empresa',
                         'nome', 'match_percent', 'cnpj', 'segmento']

    # Ajustar colunas faltantes
    for col in colunas_desejadas:
        if col not in df_less.columns:
            df_less[col] = None
        if col not in df_match.columns:
            df_match[col] = None

    # Garantir que as colunas estejam na mesma ordem
    df_less = df_less[colunas_desejadas]
    df_match = df_match[colunas_desejadas]

    # Concatenar DataFrames
    df_raw = pd.concat([df_match, df_less], ignore_index=True)

    # Convertendo DataFrame para Parquet em um buffer de memória
    buffer = BytesIO()
    table = pa.Table.from_pandas(df_raw)
    pq.write_table(table, buffer)

    # Fazendo o upload para o S3
    buffer.seek(0)
    s3_client.upload_fileobj(buffer, bucket_final, raw_file_path)

    print(f'Arquivo {raw_file_path} salvo com sucesso no bucket {bucket_final}.')


def processar_dados_reclamacoes():
    # Configurações do bucket e prefixo
    bucket_name = 'arquivo-inicial'
    bucket_final = 'grupo7-bucket-raw'
    prefix = 'Dados/Reclamacoes/'
    raw_file_path = 'raw_reclamacoes.parquet'

    # Inicializar o cliente S3
    s3_client = boto3.client('s3')

    # Listar todos os arquivos CSV no bucket com o prefixo especificado
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

    # Criar uma lista para armazenar DataFrames
    dataframes = []

    # Padroniza o nome das colunas
    column_names_reclamacoes = ['ano', 'trimestre', 'categoria', 'tipo', 'cnpj', 'instituicao_financeira', 'indice',
                                'quantidade_de_reclamacoes_reguladas_procedentes',
                                'quantidade_de_reclamacoes_reguladas_outras', 'quantidade_de_reclamacoes_nao_reguladas',
                                'quantidade_total_de_reclamacoes', 'quantidade_total_de_clientes_ccs_e_scr',
                                'quantidade_de_clientes_ccs', 'quantidade_de_clientes_scr']

    # Verifica se há arquivos no bucket com o prefixo especificado
    if 'Contents' in response:
        for obj in response['Contents']:
            file_key = obj['Key']
            if file_key.endswith('.csv'):
                try:
                    # Obter o objeto S3
                    s3_object = s3_client.get_object(Bucket=bucket_name, Key=file_key)

                    # Ler o conteúdo do arquivo CSV para um DataFrame
                    df = pd.read_csv(io.BytesIO(s3_object['Body'].read()), names=column_names_reclamacoes, sep=';',
                                     encoding='ISO-8859-1', usecols=range(14))

                    # Corrigir coluna com o tipo divergente
                    df['quantidade_total_de_reclamacoes'] = df['quantidade_total_de_reclamacoes'].astype(str)
                    df['quantidade_total_de_reclamacoes'] = df['quantidade_total_de_reclamacoes'].str.replace(r'[^\d]', '', regex=True)
                    df['quantidade_total_de_reclamacoes'] = pd.to_numeric(df['quantidade_total_de_reclamacoes'], errors='coerce').astype('Int64')

                    # Adiciona o DataFrame à lista
                    dataframes.append(df)
                except Exception as e:
                    print(f'Erro ao ler {file_key}: {e}')

        # Verifica se há DataFrames a serem concatenados
        if dataframes:
            # Concatenar todos os DataFrames
            df_raw = pd.concat(dataframes, ignore_index=True)
            
            # Convertendo DataFrame para Parquet em um buffer de memória
            buffer = BytesIO()
            table = pa.Table.from_pandas(df_raw)
            pq.write_table(table, buffer)

            # Fazendo o upload para o S3
            buffer.seek(0)  # Voltar ao início do buffer
            s3_client.upload_fileobj(buffer, bucket_final, raw_file_path)

            print(f'Arquivo {raw_file_path} salvo com sucesso no bucket {bucket_final}.')
        else:
            print('Nenhum arquivo CSV encontrado para processamento.')
    else:
        print('Nenhum arquivo encontrado no bucket com o prefixo especificado.')
