from great_expectations.data_context import DataContext

def check_data_quality():
    context = DataContext()

    batch_kwargs = {
        "path": "/mnt/data/dados_processados.csv",
        "datasource": "my_datasource"
    }
    batch = context.get_batch(batch_kwargs, "my_expectation_suite")

    validation_result = context.run_validation_operator(
        'action_list_operator', assets_to_validate=[batch]
    )

    if not validation_result['success']:
        raise ValueError("A validação dos dados falhou!")
    print("A validação dos dados foi bem-sucedida!")