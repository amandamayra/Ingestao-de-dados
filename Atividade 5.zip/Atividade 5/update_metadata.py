from datahub.emitter.mce_builder import make_dataset_urn
from datahub.emitter.rest_emitter import DatahubRestEmitter
from datahub.metadata.schema_classes import DatasetPropertiesClass, MetadataChangeProposalClass

def update_metadata():
    emitter = DatahubRestEmitter('http://localhost:8080')  
    
    dataset_urn = make_dataset_urn(platform='grupo_7', name='dados_processados', env='PROD')
    
    metadata_change_proposal = MetadataChangeProposalClass(
        entityType="dataset",
        entityUrn=dataset_urn,
        changeType="UPSERT",
        aspectName="datasetProperties",
        aspect=DatasetPropertiesClass(
            description="Dataset atualizado após verificação de qualidade de dados"
        ),
    )
    
    emitter.emit(metadata_change_proposal)
    print("Metadados atualizados no Datahub.")