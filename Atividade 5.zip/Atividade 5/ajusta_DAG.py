from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from my_scripts import processar_dados, check_data_quality, update_metadata

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 9, 17),
    'retries': 1,
}

dag = DAG(
    'data_pipeline',
    default_args=default_args,
    description='Pipeline de dados com Airflow, GreatExpectations e Datahub',
    schedule_interval='@daily',
)

# Tarefa para processar dados
t1 = PythonOperator(
    task_id='processar_dados',
    python_callable=processar_dados,
    dag=dag,
)

# Tarefa para checar qualidade de dados
t2 = PythonOperator(
    task_id='check_data_quality',
    python_callable=check_data_quality,
    dag=dag,
)

# Tarefa para atualizar metadados
t3 = PythonOperator(
    task_id='update_metadata',
    python_callable=update_metadata,
    dag=dag,
)

# Definindo a ordem de execução
t1 >> t2 >> t3