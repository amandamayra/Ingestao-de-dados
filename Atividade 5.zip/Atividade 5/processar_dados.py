import pandas as pd

# Lista de arquivos para processamento
arquivos_csv = [
    '/mnt/data/Cleaned_EnquadramentoInicia_v2.csv',
    '/mnt/data/glassdoor_consolidado_join_match_less_v2.csv',
    '/mnt/data/glassdoor_consolidado_join_match_v2.csv',
    '/mnt/data/2021_tri_01.csv',
    '/mnt/data/2021_tri_02.csv',
    '/mnt/data/2021_tri_03.csv',
    '/mnt/data/2021_tri_04.csv',
    '/mnt/data/2022_tri_01.csv',
    '/mnt/data/2022_tri_03.csv',
    '/mnt/data/2022_tri_04.csv'
]

def processar_dados():
    dataframes = []
    for arquivo in arquivos_csv:
        try:
            df = pd.read_csv(arquivo)
            df['segmento'] = df['segmento'].astype(str)
            df['cnpj'] = df['cnpj'].astype(str)
            df['nome'] = df['nome'].astype(str)
            df.rename(columns={'segmento': 'segment', 'nome': 'name'}, inplace=True)

            conversion_dict = {
                'employer_name': str, 'reviews_count': int, 'culture_count': int, 'salaries_count': float,
                'benefits_count': int, 'employer_website': str, 'employer_headquarters': str,
                'employer_founded': float, 'employer_industry': str, 'employer_revenue': str,
                'url': str, 'geral': float, 'cultura_e_valores': float, 'diversidade_e_inclusao': float,
                'qualidade_de_vida': float, 'alta_lideranca': float, 'remuneracao_e_beneficios': float,
                'oportunidades_de_carreira': float, 'percentual_recomendam_para_outras_pessoas': float,
                'percentual_perspectiva_positiva_da_empresa': float, 'cnpj': str, 'nome': str,
                'match_percent': str, 'segmento': str}

            for column, dtype in conversion_dict.items():
                df[column] = df[column].fillna(0).astype(dtype)

            rename_dict = {
                'geral': 'general', 'cultura_e_valores': 'culture_and_values', 
                'diversidade_e_inclusao': 'diversity_and_inclusion', 'qualidade_de_vida': 'quality_of_life',
                'alta_lideranca': 'high_leadership', 'remuneracao_e_beneficios': 'remuneration_and_benefits',
                'oportunidades_de_carreira': 'career_opportunities', 
                'percentual_recomendam_para_outras_pessoas': 'percentage_recommend_to_other_people',
                'percentual_perspectiva_positiva_da_empresa': 'percentage_positive_perspective_of_the_company',
                'nome': 'name', 'segmento': 'segment'
            }
            columns_to_string = ['ano', 'trimestre', 'categoria', 'tipo', 'cnpj', 'instituicao_financeira', 
                                'indice', 'quantidade_de_reclamacoes_reguladas_procedentes',
                                'quantidade_de_reclamacoes_reguladas_outras', 
                                'quantidade_de_reclamacoes_nao_reguladas', 'quantidade_total_de_reclamacoes',
                                'quantidade_total_de_clientes_ccs_e_scr', 'quantidade_de_clientes_ccs', 
                                'quantidade_de_clientes_scr']
            
            df[columns_to_string] = df[columns_to_string].astype(str)

            # Renomeação das colunas
            rename_dict = {
                'ano': 'year', 'trimestre': 'quarter', 'categoria': 'category', 
                'tipo': 'type_category', 'instituicao_financeira': 'financial_institution', 
                'indice': 'index', 'quantidade_de_reclamacoes_reguladas_procedentes': 'quantity_of_regulated_complaints_found',
                'quantidade_de_reclamacoes_reguladas_outras': 'quantity_of_regulated_complaints_others',
                'quantidade_de_reclamacoes_nao_reguladas': 'quantity_of_non_regulated_complaints',
                'quantidade_total_de_reclamacoes': 'total_quantity_of_complaints', 
                'quantidade_total_de_clientes_ccs_e_scr': 'total_quantity_of_clients_ccs_e_scr',
                'quantidade_de_clientes_ccs': 'quantity_of_ccs_clients', 
                'quantidade_de_clientes_scr': 'quantity_of_customers_scr'
            }
            df.rename(columns=rename_dict, inplace=True)

    df_concatenado = pd.concat(dataframes, ignore_index=True)
    
    df_concatenado.to_csv('/mnt/data/dados_processados.csv', index=False)
    print('Dados processados e salvos com sucesso.')