
import json
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import boto3
import pymysql
from io import BytesIO


sqs_client = boto3.client('sqs')

def le_parquet_sqs(file_name):

    response = sqs_client.get_object.file_name[0]
    file_content = response['Body'].read()
    df = pd.read_parquet(BytesIO(file_content), engine='pyarrow')
    return df

# Função para criar a tabela se não existir
def cria_tabela_se_nao_existir(connection, table_name):
    """Cria a tabela no Aurora MySQL se ela não existir."""
    create_table_sql = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        cnpj VARCHAR(20),
        segment VARCHAR(255),
        name VARCHAR(255),
        year VARCHAR(10),
        quarter VARCHAR(10),
        category VARCHAR(255),
        type_category VARCHAR(255),
        financial_institution VARCHAR(255),
        index_column VARCHAR(255),
        quantity_of_regulated_complaints_found INT,
        quantity_of_regulated_complaints_others INT,
        quantity_of_non_regulated_complaints INT,
        total_quantity_of_complaints INT,
        total_quantity_of_clients_ccs_e_scr INT,
        quantity_of_ccs_clients INT,
        quantity_of_customers_scr INT,
        employer_name VARCHAR(255),
        reviews_count INT,
        culture_count INT,
        salaries_count FLOAT,
        benefits_count INT,
        employer_website VARCHAR(255),
        employer_headquarters VARCHAR(255),
        employer_founded FLOAT,
        employer_industry VARCHAR(255),
        employer_revenue VARCHAR(255),
        url VARCHAR(255),
        general FLOAT,
        culture_and_values FLOAT,
        diversity_and_inclusion FLOAT,
        quality_of_life FLOAT,
        high_leadership FLOAT,
        remuneration_and_benefits FLOAT,
        career_opportunities FLOAT,
        percentage_recommend_to_other_people FLOAT,
        percentage_positive_perspective_of_the_company FLOAT,
        match_percent VARCHAR(255)
    );
    """
    with connection.cursor() as cursor:
        cursor.execute(create_table_sql)
    connection.commit()

# Função para salvar dados no Aurora MySQL
def save_to_aurora_mysql(df, table_name):
    """Salva um DataFrame no Aurora MySQL usando pymysql."""
    # Configurações do Aurora MySQL
    aurora_mysql_host = 'db-grupo7.cluster-chmm4000kktq.us-east-1.rds.amazonaws.com'
    aurora_mysql_user = 'admin'
    aurora_mysql_password = 'ung308(884QVx~aTL[Y>7f6MjG4r'  # Substitua pela senha correta
    aurora_mysql_db = 'dbgrupo7'

    # Conectar ao Aurora MySQL
    connection = pymysql.connect(host=aurora_mysql_host,
                                 user=aurora_mysql_user,
                                 password=aurora_mysql_password,
                                 database=aurora_mysql_db,
                                 cursorclass=pymysql.cursors.DictCursor)

    try:
        cria_tabela_se_nao_existir(connection, table_name)

        with connection.cursor() as cursor:
            # Criar o comando SQL para inserir dados
            placeholders = ', '.join(['%s'] * len(df.columns))
            columns = ', '.join(f"`{col}`" for col in df.columns)
            sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"

            # Inserir os dados linha por linha
            for row in df.itertuples(index=False):
                cursor.execute(sql, row)

        connection.commit()
        return f'Dados carregados com sucesso na tabela {table_name} no Aurora MySQL.'
    finally:
        connection.close()

def lambda_handler(event, context):
    try:
        # Ler os arquivos Parquet da camada Trusted
        df_banks = le_parquet_sqs(file_name, 'trusted_bancos.parquet')
        df_complaints = le_parquet_sqs(file_name, 'trusted_reclamacoes.parquet')
        df_employees = le_parquet_sqs(file_name, 'trusted_empregados.parquet')

        # Realizar os joins necessários
        df_inner_join = pd.merge(df_banks, df_complaints, on='cnpj', how='inner')
        df_result = pd.merge(df_inner_join, df_employees, on='cnpj', how='right')

        # Renomear colunas com sufixos _x e _y
        df_result.columns = df_result.columns.str.replace('_x', '').str.replace('_y', '')

        # Remover colunas duplicadas
        df_result = df_result.loc[:, ~df_result.columns.duplicated()]

        # Remover a coluna 'index' se ela existir
        if 'index' in df_result.columns:
            df_result.drop('index', axis=1, inplace=True)

        # Convertendo DataFrame para Parquet em um buffer de memória
        buffer = BytesIO()
        table = pa.Table.from_pandas(df_result)
        pq.write_table(table, buffer)

        # Fazer o upload do Parquet transformado para o S3
        buffer.seek(0)  # Voltar ao início do buffer
        sqs_client.upload_fileobj(buffer, bucket_final, raw_file_path)

        # Salvar o DataFrame resultante no Aurora MySQL
        mysql_result = save_to_aurora_mysql(df_result, 'tb_delivery')

        # Retornar o sucesso da operação
        return {
            'statusCode': 200,
            'body': json.dumps(f'Arquivo {raw_file_path} salvo com sucesso no bucket {bucket_final}. {mysql_result}')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(str(e))
        }
