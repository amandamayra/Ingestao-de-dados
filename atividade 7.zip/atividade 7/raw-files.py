import io
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import boto3
from io import BytesIO
import base64

def lambda_handler(event, context):
    try:
        # Parte 1: Processamento dos Dados de Bancos
        processar_dados_bancos()

        # Parte 2: Processamento dos Dados de Empregados
        processar_dados_empregados()

        # Parte 3: Processamento dos Dados de Reclamações
        processar_dados_reclamacoes()

        print('Processamento concluído com sucesso.')
    except Exception as e:
        print('Erro:', e)

def processar_dados_bancos():
    # Variáveis
    bucket_name = 'arquivo-inicial'
    file_path_bancos = 'Dados/Bancos/EnquadramentoInicia_v2.tsv'

    # Inicializar o cliente S3 e SQS
    s3_client = boto3.client('s3')
    sqs_client = boto3.client('sqs')
    
    # Nome da fila SQS
    sqs_queue_url = 'https://sqs.us-east-1.amazonaws.com/169480755728:raw-sqs'

    # Obter o arquivo S3 para a memória
    response = s3_client.get_object(Bucket=bucket_name, Key=file_path_bancos)
    file_content = response['Body'].read()

    # Ler o arquivo TSV para um DataFrame usando pandas
    columns_name = ['segmento', 'cnpj', 'nome']
    df = pd.read_csv(BytesIO(file_content), names=columns_name, header=0, sep='\\t', encoding='ISO-8859-1')

    # Convertendo DataFrame para Parquet em um buffer de memória
    buffer = BytesIO()
    table = pa.Table.from_pandas(df)
    pq.write_table(table, buffer)

    # Codificar o buffer Parquet em base64
    buffer.seek(0)  # Voltar ao início do buffer
    parquet_base64 = base64.b64encode(buffer.read()).decode('utf-8')

    # Enviar o arquivo codificado para a fila SQS
    response = sqs_client.send_message(
        QueueUrl=sqs_queue_url,
        MessageBody=parquet_base64
    )

    print('Arquivo Parquet enviado para a fila SQS com sucesso:', response)

def processar_dados_empregados():
    # Variáveis
    bucket_name = 'arquivo-inicial'
    file_path_empregados = 'Dados/Empregados/Empregados_v2.tsv'

    # Inicializar o cliente S3 e SQS
    s3_client = boto3.client('s3')
    sqs_client = boto3.client('sqs')
    
    # Nome da fila SQS
    sqs_queue_url = 'https://sqs.us-east-1.amazonaws.com/169480755728:raw-sqs'

    # Obter o arquivo S3 para a memória
    response = s3_client.get_object(Bucket=bucket_name, Key=file_path_empregados)
    file_content = response['Body'].read()

    # Ler o arquivo TSV para um DataFrame usando pandas
    columns_name = ['id', 'nome', 'departamento']
    df = pd.read_csv(BytesIO(file_content), names=columns_name, header=0, sep='\\t', encoding='ISO-8859-1')

    # Convertendo DataFrame para Parquet em um buffer de memória
    buffer = BytesIO()
    table = pa.Table.from_pandas(df)
    pq.write_table(table, buffer)

    # Codificar o buffer Parquet em base64
    buffer.seek(0)  # Voltar ao início do buffer
    parquet_base64 = base64.b64encode(buffer.read()).decode('utf-8')

    # Enviar o arquivo codificado para a fila SQS
    response = sqs_client.send_message(
        QueueUrl=sqs_queue_url,
        MessageBody=parquet_base64
    )

    print('Arquivo Parquet enviado para a fila SQS com sucesso:', response)

def processar_dados_reclamacoes():
    # Variáveis
    bucket_name = 'arquivo-inicial'
    file_path_reclamacoes = 'Dados/Reclamacoes/Reclamacoes_v2.tsv' 

    # Inicializar o cliente S3 e SQS
    s3_client = boto3.client('s3')
    sqs_client = boto3.client('sqs')
    
    # Nome da fila SQS
    sqs_queue_url = 'https://sqs.us-east-1.amazonaws.com/169480755728:raw-sqs'

    # Obter o arquivo S3 para a memória
    response = s3_client.get_object(Bucket=bucket_name, Key=file_path_reclamacoes)
    file_content = response['Body'].read()

    # Ler o arquivo TSV para um DataFrame usando pandas
    columns_name = ['id_reclamacao', 'descricao', 'status']
    df = pd.read_csv(BytesIO(file_content), names=columns_name, header=0, sep='\\t', encoding='ISO-8859-1')

    # Convertendo DataFrame para Parquet em um buffer de memória
    buffer = BytesIO()
    table = pa.Table.from_pandas(df)
    pq.write_table(table, buffer)

    # Codificar o buffer Parquet em base64
    buffer.seek(0)  # Voltar ao início do buffer
    parquet_base64 = base64.b64encode(buffer.read()).decode('utf-8')

    # Enviar o arquivo codificado para a fila SQS
    response = sqs_client.send_message(
        QueueUrl=sqs_queue_url,
        MessageBody=parquet_base64
    )

    print('Arquivo Parquet enviado para a fila SQS com sucesso:', response)
