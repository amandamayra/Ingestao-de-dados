from kafka import KafkaProducer
import json
import os

# Caminho dos dados locais
data_folder = os.path.expanduser("csv_files/")

# Inicializa o produtor Kafka
producer = KafkaProducer(bootstrap_servers='localhost:9092', value_serializer=lambda v: json.dumps(v).encode('utf-8'))

# Função para enviar dados de um arquivo para o Kafka
def send_data_to_kafka():
    for file_name in os.listdir(data_folder):
        if file_name.endswith(".csv"):
            file_path = os.path.join(data_folder, file_name)
            with open(file_path, 'r') as file:
                data = file.read()
                producer.send('dados-topico', value={'file_name': file_name, 'data': data})
    producer.flush()

if __name__ == "__main__":
    send_data_to_kafka()
    print("Dados enviados para o Kafka com sucesso.")