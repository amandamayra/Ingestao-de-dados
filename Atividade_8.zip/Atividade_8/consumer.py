from pyspark.sql import SparkSession
from pyspark.sql.functions import col, regexp_replace
import mysql.connector
import os
import time

# Configurações do MySQL
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'A170498b!',
    'database': 'grupo7',
    'port': 3306
}

# Função para limpar e padronizar os dados
def clean_data(df):
    df = df.dropDuplicates()
    df = df.fillna(0)

    # Padronizar os nomes das colunas para lowercase e remover caracteres especiais
    for col_name in df.columns:
        new_col_name = col_name.lower().replace(" ", "_")
        new_col_name = regexp_replace(new_col_name, "[^a-zA-Z0-9_]", "")
        df = df.withColumnRenamed(col_name, new_col_name)
    
    return df

# Função para garantir unicidade dos nomes das colunas
def ensure_unique_columns(columns):
    mapping = {}
    result = []
    for col in columns:
        col_normalized = normalize_column_name(col)
        if col_normalized in mapping:
            mapping[col_normalized] += 1
            unique_col = f"{col_normalized}_{mapping[col_normalized]}"
            result.append(unique_col[:64])
        else:
            mapping[col_normalized] = 0
            result.append(col_normalized)
    return result

def normalize_column_name(name):
    normalized = (
        name.strip().lower().replace(' ', '_').replace(';', '_')
        .replace('.', '_').replace('-', '_').replace('(', '')
        .replace(')', '').replace('ç', 'c').replace('ã', 'a')
        .replace('á', 'a').replace('é', 'e').replace('í', 'i')
        .replace('ó', 'o').replace('ú', 'u').replace('â', 'a')
        .replace('ê', 'e').replace('ô', 'o').replace(':', '_')
        .replace('__', '_')
    )
    return normalized[:64]

# Função para adicionar colunas faltantes no MySQL
def add_missing_columns(cursor, table, columns):
    cursor.execute(f"DESCRIBE {table}")
    existing_columns = {row[0] for row in cursor.fetchall()}
    new_columns = set(columns) - existing_columns
    for col in new_columns:
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN `{col}` TEXT")

# Conectar ao MySQL
def connect_to_mysql():
    max_retries = 5
    retry_count = 0
    while retry_count < max_retries:
        try:
            conn = mysql.connector.connect(**db_config)
            cursor = conn.cursor()
            return conn, cursor
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            print(f"Retrying ({retry_count+1}/{max_retries})...")
            retry_count += 1
            time.sleep(10)
    raise Exception("Failed to connect to MySQL after several attempts")

# Função para salvar no MySQL
def save_to_mysql(df, table_name):
    conn, cursor = connect_to_mysql()
    
    pandas_df = df.toPandas()
    pandas_df.columns = ensure_unique_columns(pandas_df.columns)
    
    cursor.execute(f"CREATE TABLE IF NOT EXISTS `{table_name}` (id INT AUTO_INCREMENT PRIMARY KEY)")
    add_missing_columns(cursor, table_name, pandas_df.columns)
    
    for _, row in pandas_df.iterrows():
        columns = ", ".join([f"`{col}`" for col in pandas_df.columns])
        values = ", ".join(["%s"] * len(pandas_df.columns))
        insert_query = f"INSERT INTO `{table_name}` ({columns}) VALUES ({values})"
        cursor.execute(insert_query, tuple(row))
    
    conn.commit()
    cursor.close()
    conn.close()

# Criar a sessão Spark
spark = SparkSession.builder.appName("KafkaConsumer").getOrCreate()

# Ler dados do Kafka
df = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "dados-topico").load()

df = df.selectExpr("CAST(value AS STRING)")

def process_batch(df, epoch_id):
    df_clean = clean_data(df)
    save_to_mysql(df_clean, "tabela_enriquecida")

# Configurar o processamento em streaming
query = df.writeStream.foreachBatch(process_batch).outputMode("append").start()
query.awaitTermination()